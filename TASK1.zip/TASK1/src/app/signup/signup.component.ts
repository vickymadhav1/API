import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router} from '@angular/router';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  eventname:string;
  organisername:string;
  dateofevent:string;
  eventloactaion:string;
  constructor(private _http:Http,private router:Router) { }

  ngOnInit() {
  }
 onSubmit(a)
 {
   
  this.eventname=a.eventname;
  this.organisername=a.organisername;
  this.dateofevent=a.dateofevent;
  this.eventloactaion=a.eventloactaion;
 
  console.log(this.eventname);
  console.log(a);
  var headers= new Headers();
  headers.append('Content-Type', 'application/json');
  let options = new RequestOptions({ headers: headers });
  
this._http.post('/api/signup',a, options)
          .subscribe(data => 
            {
                alert('Created Event Successfully');
                this.router.navigate(['/api/data']);
                
          }, error => {
              console.log(JSON.stringify(error.json()));
          })

 }

}




