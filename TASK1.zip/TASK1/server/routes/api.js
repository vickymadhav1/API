var app = require('express')();
var mongo = require('mongodb').MongoClient;
var mongoose = require('mongoose');

app.get('/book', function(req, res) {
    var id = req.query.bookId;

    Book.find({ _id: id }, function(err, book) {
        if(err) throw err;
        
        res.send(book[0]);
    });
});
app.post('/signup', function(req, res) {
  
    var obj={eventname:req.body.eventname,
        organisername:req.body.organisername,
        dateofevent:req.body.dateofevent,
        eventloactaion:req.body.eventloactaion};
  mongo.connect("mongodb://localhost:27017/API",function(err,db){
    if(err) throw err;
    db.collection('datastore').insert(obj,function(err,res){
        if(err)
        console.log.apply(err);
        console.log("Created successfully ");
    })
    res.send("Creted");
    });
    });
    app.get('/data', function(req, res) {
        mongo.connect("mongodb://localhost:27017/API",function(err,db){
            if(err) throw err;
            console.log("mongo is connected");
            db.collection('datastore').find({}).toArray( function(err, sample) {
                if(err) throw err;
        console.log(sample);
        res.send(sample);
            });
        });  
    });

module.exports = app;















